from django.test import TestCase

# Create your tests here.
import uuid

# Generate a UUID
unique_id = uuid.uuid1()
print(unique_id)
